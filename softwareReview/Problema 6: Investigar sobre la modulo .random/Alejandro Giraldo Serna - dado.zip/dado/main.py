from functions.function import menuPrincipal
from functions.logica import iniciar_juego

def main():
    while (True):
        opc = menuPrincipal()
        
        match (opc):             
            case 1:
                iniciar_juego()
            case 2:
                break

main()